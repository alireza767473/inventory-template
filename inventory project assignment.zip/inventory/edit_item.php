<?php
  include("include/header.php");
  $conn = mysqli_connect("localhost","root","","inventory");
  mysqli_set_charset($conn,"utf8");
    
     if (isset($_POST["subbtn"])) {
                     

        $id = $_GET["id"];

 $itemname = $_POST["iname"];
    $itemprice = $_POST["cost"];
    $itemdate=$_POST["idate"];


    $sqll = "UPDATE item SET item_name='$itemname', item_price='$itemprice',item_date='$itemdate' WHERE item_id=$id";
    $result = mysqli_query($conn,$sqll);
    
          if ($result) {
            echo "موفقانه اطلاعات راجع به جنس ویرایش شد";
          }else {
            echo "اطلاعات ویرایش نشد مشکل رخ داده است";
          }


  }else{
    $id = $_GET["id"];
    $sql = "SELECT *FROM item WHERE item_id='$id'";
    $result = mysqli_query($conn,$sql);
    $row= mysqli_fetch_row($result);

  }
 ?>
  <body>
  <div class="container-fluid">
    <div class="row1">
      <div class="row">

<br>
    <div class="col-md-4">
      <ul class="nav nav-pills">
        <li role="presentation" class="active"><a href="list_emp.php">برگشت</a>
        </li>

      </ul>

    </div>
  </div>
    <div class="col-md-8 col-md-offset-2" dir="rtl">
      <h2>ویرایش جنس</h2>
    <br/>

        <form class="form-horizontal" method="post">
          <div class="form-group">

              <div class="col-sm-10">
                <input type="text" value = "<?php if (!empty($row[1])) {
                  echo $row[1];
                } ?>" name="iname" class="form-control" id ="iname" placeholder="نام را وارد کنید" >

              </div>
              <label for="iname" class="col-sm-2 control-label">نام حنس</label>
          </div>

          <div class="form-group">

              <div class="col-sm-10">
                <input type="text" value = "<?php if (!empty($row[2])) {
                  echo $row[2];
                } ?>" name="cost" class="form-control" id ="cost" placeholder="تخلص را وارد کنید">

              </div>
              <label for="cost" class="col-sm-2 control-label">قیمت حنس</label>
          </div>
          <div class="form-group">

              <div class="col-sm-10">
                <input type="text" value = "<?php if (!empty($row[3])) {
                  echo $row[3];
                } ?>" name="idate" class="form-control" id ="idate" placeholder="نام پدر را وارد کنید" >

              </div>
             
              <label for="idate" class="col-sm-2 control-label">تاریخ </label>
          </div>
          <div class="form-group">
            <div class="col-md-2">
              <button type="submit" name="subbtn" class="btn btn-success btn-block">اضافه کردن</button>

            </div>
            <div class="col-md-10">

            </div>


          </div>


        </form>

    </div>
  </div>

  </body>
</html>
